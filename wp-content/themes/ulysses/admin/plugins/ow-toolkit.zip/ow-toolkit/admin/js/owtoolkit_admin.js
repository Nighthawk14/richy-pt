(function( $ ) {
	'use strict';

})( jQuery );
